package ru.gemini.voidwars;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.*;

import java.util.*;
import java.io.File;
import java.io.IOException;

public class VoidWars extends JavaPlugin implements Listener, CommandExecutor {

    private String prefix;
    private Map<String, Arena> arenas = new HashMap<>();
    private Map<Player, String> playerArenaMap = new HashMap<>();
    private Set<Location> placedBlocks = new HashSet<>();
    private Map<Player, Integer> pickaxeLevel = new HashMap<>();
    private Map<Player, Integer> axeLevel = new HashMap<>();
    
    // Файл конфигурации скорборда
    private FileConfiguration scoreboardConfig;

    @Override
    public void onEnable() {
        saveDefaultConfig(); 
        createScoreboardConfig();
        
        if (!getDataFolder().exists()) {
            getDataFolder().mkdirs();
        }
        File arenasDir = new File(getDataFolder(), "arenas");
        if (!arenasDir.exists()) {
            arenasDir.mkdirs();
        }
        
        File statsDir = new File(getDataFolder(), "stats");
        if (!statsDir.exists()) {
            statsDir.mkdirs();
        }
        
        reloadPluginData();

        getServer().getPluginManager().registerEvents(this, this);
        if (getCommand("voidwars") != null) {
            getCommand("voidwars").setExecutor(this);
        }
        
        startGlobalTask();
        getLogger().info("VoidWars: Система полностью загружена. BedWars механики активированы.");
    }

    private void createScoreboardConfig() {
        File file = new File(getDataFolder(), "scoreboard.yml");
        if (!file.exists()) {
            try {
                file.createNewFile();
                YamlConfiguration conf = YamlConfiguration.loadConfiguration(file);
                conf.set("scoreboard.title", "&b&lVOID WARS");
                List<String> lines = Arrays.asList(
                    "&7----------------",
                    "Кровать: %bed_status%",
                    "Живых: &e%alive_count%",
                    "Арена: &f%arena_name%",
                    "&7----------------",
                    "&ewww.server.ru"
                );
                conf.set("scoreboard.lines", lines);
                conf.save(file);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        scoreboardConfig = YamlConfiguration.loadConfiguration(file);
    }

    public void reloadPluginData() {
        reloadConfig();
        createScoreboardConfig();
        this.prefix = ChatColor.translateAlternateColorCodes('&', getConfig().getString("settings.prefix", "&b&lVOIDWARS &8» &r"));
        
        // Очищаем старые данные арен перед перезагрузкой
        for (Arena arena : arenas.values()) {
            arena.clearNPCs();
        }
        arenas.clear();
        loadArenasFromFolder();
    }

    private void loadArenasFromFolder() {
        File arenasDir = new File(getDataFolder(), "arenas");
        File[] files = arenasDir.listFiles();
        if (files == null) return;
        for (File file : files) {
            if (file.getName().endsWith(".yml")) {
                String arenaName = file.getName().replace(".yml", "");
                FileConfiguration res = YamlConfiguration.loadConfiguration(file);
                Arena arena = new Arena(arenaName);
                if (Bukkit.getWorld(arenaName) == null) {
                    createVoidWorld(arenaName);
                }
                if (res.contains("lobby")) {
                    arena.setLobby((Location) res.get("lobby"));
                }
                if (res.contains("teams")) {
                    ConfigurationSection teamsSec = res.getConfigurationSection("teams");
                    for (String color : teamsSec.getKeys(false)) {
                        Location bed = (Location) teamsSec.get(color + ".bed");
                        Location spawn = (Location) teamsSec.get(color + ".spawn");
                        Location shop = (Location) teamsSec.get(color + ".shop");
                        Location upgrade = (Location) teamsSec.get(color + ".upgrade");
                        arena.addTeam(color, spawn, bed);
                        if (shop != null) arena.getTeamShops().put(color, shop);
                        if (upgrade != null) arena.getTeamUpgrades().put(color, upgrade);
                    }
                }
                if (res.contains("generators.diamond")) {
                    arena.getDiamondGenerators().addAll((List<Location>) res.get("generators.diamond"));
                }
                if (res.contains("generators.emerald")) {
                    arena.getEmeraldGenerators().addAll((List<Location>) res.get("generators.emerald"));
                }
                arenas.put(arenaName, arena);
            }
        }
    }

    public void saveArenaToFile(Arena arena) {
        File file = new File(getDataFolder() + "/arenas", arena.getName() + ".yml");
        FileConfiguration config = YamlConfiguration.loadConfiguration(file);
        config.set("lobby", arena.getLobby());
        for (String team : arena.getTeamSpawns().keySet()) {
            config.set("teams." + team + ".spawn", arena.getTeamSpawns().get(team));
            config.set("teams." + team + ".bed", arena.getTeamBeds().get(team));
            config.set("teams." + team + ".shop", arena.getTeamShops().get(team));
            config.set("teams." + team + ".upgrade", arena.getTeamUpgrades().get(team));
        }
        config.set("generators.diamond", arena.getDiamondGenerators());
        config.set("generators.emerald", arena.getEmeraldGenerators());
        try { config.save(file); } catch (IOException e) { e.printStackTrace(); }
    }

    private void createVoidWorld(String name) {
        WorldCreator wc = new WorldCreator(name);
        wc.generator(new org.bukkit.generator.ChunkGenerator() {
            @Override public byte[] generate(World world, Random random, int x, int z) { return new byte[32768]; }
        });
        Bukkit.createWorld(wc);
    }

    private void startGlobalTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Arena arena : arenas.values()) {
                    if (arena.getState() == ArenaState.INGAME) {
                        arena.runGameTick();
                        arena.updateScoreboard();
                        for (Player p : arena.getPlayers()) {
                            if (p.getLocation().getY() < 0 && p.getGameMode() == GameMode.SURVIVAL) {
                                p.setHealth(0);
                            }
                        }
                    }
                }
            }
        }.runTaskTimer(this, 0, 20);
    }

    private void playUniversalSound(Player p, String oldS, String newS) {
        try { p.playSound(p.getLocation(), Sound.valueOf(newS), 1f, 1f); } 
        catch (Exception e) { try { p.playSound(p.getLocation(), Sound.valueOf(oldS), 1f, 1f); } catch (Exception ex) {} }
    }

    private ChatColor getTeamChatColor(String color) {
        try {
            if (color.equalsIgnoreCase("red")) return ChatColor.RED;
            if (color.equalsIgnoreCase("blue")) return ChatColor.BLUE;
            if (color.equalsIgnoreCase("green")) return ChatColor.GREEN;
            if (color.equalsIgnoreCase("yellow")) return ChatColor.YELLOW;
            if (color.equalsIgnoreCase("white")) return ChatColor.WHITE;
            return ChatColor.valueOf(color.toUpperCase());
        } catch (Exception e) {
            return ChatColor.GRAY;
        }
    }

    private void giveTeamArmor(Player p, String colorName) {
        Color color = Color.GRAY;
        if (colorName.equalsIgnoreCase("red")) color = Color.RED;
        else if (colorName.equalsIgnoreCase("blue")) color = Color.BLUE;
        else if (colorName.equalsIgnoreCase("green")) color = Color.GREEN;
        else if (colorName.equalsIgnoreCase("yellow")) color = Color.YELLOW;

        p.getInventory().setHelmet(createColoredArmor(Material.LEATHER_HELMET, color));
        p.getInventory().setChestplate(createColoredArmor(Material.LEATHER_CHESTPLATE, color));
        p.getInventory().setLeggings(createColoredArmor(Material.LEATHER_LEGGINGS, color));
        p.getInventory().setBoots(createColoredArmor(Material.LEATHER_BOOTS, color));
    }

    private ItemStack createColoredArmor(Material mat, Color color) {
        ItemStack item = new ItemStack(mat);
        LeatherArmorMeta meta = (LeatherArmorMeta) item.getItemMeta();
        meta.setColor(color);
        meta.spigot().setUnbreakable(true);
        item.setItemMeta(meta);
        return item;
    }

    // --- СТАТИСТИКА ---

    public void addStat(Player p, String key, int amount) {
        File file = new File(getDataFolder() + "/stats", p.getUniqueId() + ".yml");
        FileConfiguration config = YamlConfiguration.loadConfiguration(file);
        int current = config.getInt(key, 0);
        config.set(key, current + amount);
        try { config.save(file); } catch (IOException e) { e.printStackTrace(); }
    }

    public int getStat(Player p, String key) {
        File file = new File(getDataFolder() + "/stats", p.getUniqueId() + ".yml");
        if (!file.exists()) return 0;
        FileConfiguration config = YamlConfiguration.loadConfiguration(file);
        return config.getInt(key, 0);
    }

    // --- МАГАЗИН И GUI ---

    public void openCategoryMenu(Player p) {
        Inventory inv = Bukkit.createInventory(null, 27, "§8Магазин предметов");
        inv.setItem(10, createGuiItem(Material.WOOL, "§eБлоки", "§7Шерсть, дерево..."));
        inv.setItem(11, createGuiItem(Material.GOLD_SWORD, "§eОружие", "§7Мечи и палки..."));
        inv.setItem(12, createGuiItem(Material.CHAINMAIL_CHESTPLATE, "§eБроня", "§7Кольчуга, Алмазы..."));
        inv.setItem(13, createGuiItem(Material.STONE_PICKAXE, "§eИнструменты", "§7Кирки и Топоры..."));
        inv.setItem(16, createGuiItem(Material.TNT, "§cРазное", "§7ТНТ, Файерболы, Жемчуг..."));
        p.openInventory(inv);
    }

    public void openBlocksMenu(Player p) {
        Inventory inv = Bukkit.createInventory(null, 36, "§8Магазин: Блоки");
        setShopItem(inv, 10, Material.WOOL, "§fШерсть (16 шт)", 16, 4, Material.IRON_INGOT);
        setShopItem(inv, 11, Material.WOOD, "§6Доски (16 шт)", 16, 8, Material.IRON_INGOT);
        setShopItem(inv, 12, Material.ENDER_STONE, "§eЭндерняк (12 шт)", 12, 24, Material.IRON_INGOT);
        setShopItem(inv, 13, Material.OBSIDIAN, "§5Обсидиан (4 шт)", 4, 4, Material.EMERALD);
        inv.setItem(31, createGuiItem(Material.ARROW, "§cНазад", "§7Вернуться в категории"));
        p.openInventory(inv);
    }

    public void openWeaponMenu(Player p) {
        Inventory inv = Bukkit.createInventory(null, 36, "§8Магазин: Оружие");
        setShopItem(inv, 10, Material.STONE_SWORD, "§7Каменный меч", 1, 10, Material.IRON_INGOT);
        setShopItem(inv, 11, Material.IRON_SWORD, "§fЖелезный меч", 1, 7, Material.GOLD_INGOT);
        setShopItem(inv, 12, Material.DIAMOND_SWORD, "§bАлмазный меч", 1, 4, Material.EMERALD);
        setShopItem(inv, 13, Material.STICK, "§eПалка-откидывалка", 1, 10, Material.GOLD_INGOT);
        inv.setItem(31, createGuiItem(Material.ARROW, "§cНазад", "§7Вернуться в категории"));
        p.openInventory(inv);
    }

    public void openToolsMenu(Player p) {
        Inventory inv = Bukkit.createInventory(null, 36, "§8Магазин: Инструменты");
        int pLvl = pickaxeLevel.getOrDefault(p, 0);
        int aLvl = axeLevel.getOrDefault(p, 0);

        if (pLvl == 0) setShopItem(inv, 10, Material.WOOD_PICKAXE, "§fДеревянная кирка", 1, 10, Material.IRON_INGOT);
        else if (pLvl == 1) setShopItem(inv, 10, Material.STONE_PICKAXE, "§7Каменная кирка", 1, 20, Material.IRON_INGOT);
        else if (pLvl == 2) setShopItem(inv, 10, Material.IRON_PICKAXE, "§fЖелезная кирка", 1, 8, Material.GOLD_INGOT);
        else if (pLvl == 3) setShopItem(inv, 10, Material.DIAMOND_PICKAXE, "§bАлмазная кирка", 1, 12, Material.GOLD_INGOT);

        if (aLvl == 0) setShopItem(inv, 11, Material.WOOD_AXE, "§fДеревянный топор", 1, 10, Material.IRON_INGOT);
        else if (aLvl == 1) setShopItem(inv, 11, Material.STONE_AXE, "§7Каменный топор", 1, 20, Material.IRON_INGOT);
        
        setShopItem(inv, 12, Material.SHEARS, "§fНожницы", 1, 20, Material.IRON_INGOT);
        inv.setItem(31, createGuiItem(Material.ARROW, "§cНазад", "§7Вернуться в категории"));
        p.openInventory(inv);
    }

    public void openMiscMenu(Player p) {
        Inventory inv = Bukkit.createInventory(null, 36, "§8Магазин: Разное");
        setShopItem(inv, 10, Material.GOLDEN_APPLE, "§6Золотое яблоко", 1, 3, Material.GOLD_INGOT);
        setShopItem(inv, 11, Material.FIREBALL, "§cОгненный шар", 1, 40, Material.IRON_INGOT);
        setShopItem(inv, 12, Material.TNT, "§cТНТ", 1, 4, Material.GOLD_INGOT);
        setShopItem(inv, 13, Material.ENDER_PEARL, "§dЭндер-жемчуг", 1, 4, Material.EMERALD);
        setShopItem(inv, 14, Material.WATER_BUCKET, "§bВедро воды", 1, 3, Material.GOLD_INGOT);
        inv.setItem(31, createGuiItem(Material.ARROW, "§cНазад", "§7Вернуться в категории"));
        p.openInventory(inv);
    }

    public void openUpgradesMenu(Player p) {
        Inventory inv = Bukkit.createInventory(null, 27, "§8Улучшения команды");
        Arena arena = arenas.get(playerArenaMap.get(p));
        String team = arena.getPlayerTeam(p);
        int sharpLevel = arena.getTeamSharpness().getOrDefault(team, 0);
        int protLevel = arena.getTeamProtection().getOrDefault(team, 0);

        setShopItem(inv, 10, Material.DIAMOND_SWORD, "§bОстрота", 1, (sharpLevel + 1) * 4, Material.DIAMOND);
        setShopItem(inv, 11, Material.IRON_CHESTPLATE, "§bЗащита", 1, (protLevel + 1) * 4, Material.DIAMOND);
        setShopItem(inv, 12, Material.FEATHER, "§bМания спешки", 1, 2, Material.DIAMOND);
        setShopItem(inv, 16, Material.BLAZE_POWDER, "§cУлучшение генераторов", 1, 4, Material.DIAMOND);
        p.openInventory(inv);
    }

    private ItemStack createGuiItem(Material mat, String name, String lore) {
        ItemStack item = new ItemStack(mat != null ? mat : Material.STONE);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(Collections.singletonList(lore));
        item.setItemMeta(meta);
        return item;
    }

    private void setShopItem(Inventory inv, int slot, Material mat, String name, int amount, int price, Material currency) {
        ItemStack item = new ItemStack(mat != null ? mat : Material.STONE, amount);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        String cName = "Железо";
        if (currency == Material.GOLD_INGOT) cName = "Золото";
        if (currency == Material.EMERALD) cName = "Изумруды";
        if (currency == Material.DIAMOND) cName = "Алмазы";
        
        meta.setLore(Arrays.asList("§7Цена: §e" + price + " " + cName, "", "§eНажми для покупки"));
        if (mat == Material.STICK) meta.addEnchant(Enchantment.KNOCKBACK, 1, true);
        item.setItemMeta(meta);
        inv.setItem(slot, item);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        String title = e.getView().getTitle();
        if (title.startsWith("§8Магазин") || title.equals("§8Улучшения команды")) {
            e.setCancelled(true);
            Player p = (Player) e.getWhoClicked();
            ItemStack item = e.getCurrentItem();
            if (item == null || !item.hasItemMeta()) return;
            String name = item.getItemMeta().getDisplayName();

            if (name.equals("§eБлоки")) openBlocksMenu(p);
            else if (name.equals("§eОружие")) openWeaponMenu(p);
            else if (name.equals("§eИнструменты")) openToolsMenu(p);
            else if (name.equals("§cРазное")) openMiscMenu(p);
            else if (name.equals("§cНазад")) openCategoryMenu(p);
            else if (name.equals("§bОстрота")) handleUpgrade(p, "sharpness");
            else if (name.equals("§bЗащита")) handleUpgrade(p, "protection");
            else if (item.getItemMeta().hasLore()) {
                handlePurchase(p, item);
            }
        }
    }

    private void handlePurchase(Player p, ItemStack item) {
        List<String> lore = item.getItemMeta().getLore();
        String firstLine = ChatColor.stripColor(lore.get(0));
        String[] parts = firstLine.split(" ");
        int price = Integer.parseInt(parts[1]);
        String currName = parts[2];
        
        Material currency = Material.IRON_INGOT;
        if (currName.equalsIgnoreCase("Золото")) currency = Material.GOLD_INGOT;
        else if (currName.equalsIgnoreCase("Изумруды")) currency = Material.EMERALD;
        else if (currName.equalsIgnoreCase("Алмазы")) currency = Material.DIAMOND;

        boolean hasResources = false;
        if ((currency == Material.IRON_INGOT || currency == Material.GOLD_INGOT) && p.getLevel() >= price) {
            p.setLevel(p.getLevel() - price);
            hasResources = true;
        } else if (p.getInventory().containsAtLeast(new ItemStack(currency), price)) {
            p.getInventory().removeItem(new ItemStack(currency, price));
            hasResources = true;
        }

        if (hasResources) {
            Material type = item.getType();
            if (type.name().contains("PICKAXE")) pickaxeLevel.put(p, pickaxeLevel.getOrDefault(p, 0) + 1);
            if (type.name().contains("AXE")) axeLevel.put(p, axeLevel.getOrDefault(p, 0) + 1);

            ItemStack give = item.clone();
            ItemMeta m = give.getItemMeta(); 
            m.setLore(null); 
            give.setItemMeta(m);
            p.getInventory().addItem(give);
            
            p.sendMessage(prefix + "§aВы купили §f" + ChatColor.stripColor(item.getItemMeta().getDisplayName()));
            playUniversalSound(p, "ORB_PICKUP", "ENTITY_EXPERIENCE_ORB_PICKUP");
            
            Arena arena = arenas.get(playerArenaMap.get(p));
            if (arena != null) applyTeamEffects(p, arena);
        } else {
            p.sendMessage(prefix + "§cУ вас недостаточно ресурсов (или опыта)!");
        }
    }

    private void handleUpgrade(Player p, String type) {
        Arena arena = arenas.get(playerArenaMap.get(p));
        String team = arena.getPlayerTeam(p);
        if (type.equals("sharpness")) {
            int level = arena.getTeamSharpness().getOrDefault(team, 0);
            int cost = (level + 1) * 4;
            if (p.getInventory().containsAtLeast(new ItemStack(Material.DIAMOND), cost)) {
                p.getInventory().removeItem(new ItemStack(Material.DIAMOND, cost));
                arena.getTeamSharpness().put(team, level + 1);
                arena.broadcastTeam(team, prefix + "§aКоманда получила Остроту " + (level + 1));
                for(Player tp : arena.getPlayers()) if(arena.getPlayerTeam(tp).equals(team)) applyTeamEffects(tp, arena);
            }
        } else if (type.equals("protection")) {
            int level = arena.getTeamProtection().getOrDefault(team, 0);
            int cost = (level + 1) * 4;
            if (p.getInventory().containsAtLeast(new ItemStack(Material.DIAMOND), cost)) {
                p.getInventory().removeItem(new ItemStack(Material.DIAMOND, cost));
                arena.getTeamProtection().put(team, level + 1);
                arena.broadcastTeam(team, prefix + "§aКоманда получила Защиту " + (level + 1));
                for(Player tp : arena.getPlayers()) if(arena.getPlayerTeam(tp).equals(team)) applyTeamEffects(tp, arena);
            }
        }
    }

    private void applyTeamEffects(Player p, Arena arena) {
        String team = arena.getPlayerTeam(p);
        int sharp = arena.getTeamSharpness().getOrDefault(team, 0);
        int prot = arena.getTeamProtection().getOrDefault(team, 0);
        for (ItemStack item : p.getInventory().getContents()) {
            if (item == null) continue;
            if (item.getType().name().contains("SWORD") && sharp > 0) {
                item.addUnsafeEnchantment(Enchantment.DAMAGE_ALL, sharp);
            }
            if ((item.getType().name().contains("BOOTS") || item.getType().name().contains("LEGGINGS") || item.getType().name().contains("CHESTPLATE") || item.getType().name().contains("HELMET")) && prot > 0) {
                item.addUnsafeEnchantment(Enchantment.PROTECTION_ENVIRONMENTAL, prot);
            }
        }
    }

    // --- МЕХАНИКИ BedWars ---

    @EventHandler
    public void onBlockPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        if (!playerArenaMap.containsKey(p)) return;
        Arena arena = arenas.get(playerArenaMap.get(p));
        if (arena.getState() != ArenaState.INGAME) {
            e.setCancelled(true);
            return;
        }

        placedBlocks.add(e.getBlock().getLocation());
        if (e.getBlock().getType() == Material.TNT) {
            e.getBlock().setType(Material.AIR);
            e.getBlock().getWorld().spawnEntity(e.getBlock().getLocation().add(0.5, 0, 0.5), EntityType.PRIMED_TNT);
        }
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (!playerArenaMap.containsKey(p)) return;
        Arena arena = arenas.get(playerArenaMap.get(p));
        Location loc = e.getBlock().getLocation();

        if (e.getBlock().getType().name().contains("BED")) {
            for (String color : arena.getTeamBeds().keySet()) {
                Location bedLoc = arena.getTeamBeds().get(color);
                if (bedLoc != null && bedLoc.getWorld().equals(loc.getWorld()) && bedLoc.distance(loc) < 3.0) {
                    if (color.equalsIgnoreCase(arena.getPlayerTeam(p))) {
                        p.sendMessage("§cВы не можете сломать свою кровать!");
                        e.setCancelled(true);
                    } else {
                        arena.breakBed(color, p);
                        addStat(p, "beds_broken", 1);
                        e.setDropItems(false);
                    }
                    return;
                }
            }
        }

        if (!placedBlocks.contains(loc)) {
            e.setCancelled(true);
            p.sendMessage("§cЗдесь нельзя ломать блоки карты!");
        } else {
            placedBlocks.remove(loc);
        }
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent e) {
        Player p = e.getPlayer();
        if (playerArenaMap.containsKey(p)) {
            Arena arena = arenas.get(playerArenaMap.get(p));
            String team = arena.getPlayerTeam(p);
            ChatColor teamColor = getTeamChatColor(team);
            if (e.getMessage().startsWith("!")) {
                e.setFormat("§6[ВСЕ] " + teamColor + p.getName() + "§7: §f" + e.getMessage().substring(1));
            } else {
                e.setCancelled(true);
                arena.broadcastTeam(team, "§8[" + teamColor + "КОМАНДА§8] " + teamColor + p.getName() + "§7: §f" + e.getMessage());
            }
        }
    }

    @EventHandler
    public void onInteractVillager(PlayerInteractEntityEvent e) {
        if (e.getRightClicked() instanceof Villager) {
            Villager v = (Villager) e.getRightClicked();
            if (v.getCustomName() == null) return;
            e.setCancelled(true);
            if (v.getCustomName().contains("ТОРГОВЕЦ")) openCategoryMenu(e.getPlayer());
            else if (v.getCustomName().contains("УЛУЧШЕНИЯ")) openUpgradesMenu(e.getPlayer());
        }
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        if (!playerArenaMap.containsKey(p)) return;
        e.setDeathMessage(null);
        Arena arena = arenas.get(playerArenaMap.get(p));
        String team = arena.getPlayerTeam(p);
        ChatColor pColor = getTeamChatColor(team);

        String deathMsg = pColor + p.getName() + " §7упал в бездну";
        if (p.getKiller() != null) {
            Player k = p.getKiller();
            String kTeam = arena.getPlayerTeam(k);
            ChatColor kColor = getTeamChatColor(kTeam);
            deathMsg = pColor + p.getName() + " §7был убит игроком " + kColor + k.getName();
            
            addStat(k, "kills", 1);
            
            for (ItemStack item : p.getInventory().getContents()) {
                if (item == null) continue;
                Material type = item.getType();
                if (type == Material.IRON_INGOT || type == Material.GOLD_INGOT || type == Material.EMERALD || type == Material.DIAMOND) {
                    k.getInventory().addItem(item);
                }
            }
            k.setLevel(k.getLevel() + p.getLevel());
        }
        
        if (arena.isBedBroken(team)) {
            deathMsg += " §b§lФИНАЛЬНОЕ УБИЙСТВО!";
        }
        arena.broadcast(deathMsg);

        e.getDrops().clear();
        new BukkitRunnable() {
            @Override public void run() {
                p.spigot().respawn();
                p.setLevel(0); 
                if (arena.isBedBroken(team)) {
                    p.setGameMode(GameMode.SPECTATOR);
                    p.sendTitle("§c§lВЫ ВЫБЫЛИ!", "§7Кровать была сломана", 10, 70, 20);
                } else {
                    p.teleport(arena.getTeamSpawns().get(team));
                    p.getInventory().addItem(new ItemStack(Material.WOOD_SWORD));
                    giveTeamArmor(p, team);
                    applyTeamEffects(p, arena);
                }
                arena.checkWinCondition();
            }
        }.runTaskLater(this, 1);
    }

    @EventHandler
    public void onFood(FoodLevelChangeEvent e) {
        if (e.getEntity() instanceof Player && playerArenaMap.containsKey((Player)e.getEntity())) {
            e.setFoodLevel(20);
        }
    }

    // --- КЛАСС АРЕНЫ ---

    public enum ArenaState { WAITING, STARTING, INGAME }

    public class Arena {
        private String name;
        private Location lobby;
        private ArenaState state = ArenaState.WAITING;
        private Map<String, Location> teamSpawns = new HashMap<>();
        private Map<String, Location> teamBeds = new HashMap<>();
        private Map<String, Location> teamShops = new HashMap<>();
        private Map<String, Location> teamUpgrades = new HashMap<>();
        private Map<String, Boolean> brokenBeds = new HashMap<>();
        private Map<Player, String> playerTeams = new HashMap<>();
        private Map<String, Integer> teamSharpness = new HashMap<>();
        private Map<String, Integer> teamProtection = new HashMap<>();
        private List<Location> diamondGenerators = new ArrayList<>();
        private List<Location> emeraldGenerators = new ArrayList<>();
        private List<Player> players = new ArrayList<>();
        private List<Villager> npcs = new ArrayList<>();
        private int timer = 20;

        public Arena(String name) { this.name = name; }
        public String getName() { return name; }
        public ArenaState getState() { return state; }
        public void setLobby(Location l) { this.lobby = l; }
        public Location getLobby() { return lobby; }
        public List<Player> getPlayers() { return players; }
        public Map<String, Location> getTeamSpawns() { return teamSpawns; }
        public Map<String, Location> getTeamBeds() { return teamBeds; }
        public Map<String, Location> getTeamShops() { return teamShops; }
        public Map<String, Location> getTeamUpgrades() { return teamUpgrades; }
        public List<Location> getDiamondGenerators() { return diamondGenerators; }
        public List<Location> getEmeraldGenerators() { return emeraldGenerators; }
        public String getPlayerTeam(Player p) { return playerTeams.get(p); }
        public boolean isBedBroken(String team) { return brokenBeds.getOrDefault(team, false); }
        public Map<String, Integer> getTeamSharpness() { return teamSharpness; }
        public Map<String, Integer> getTeamProtection() { return teamProtection; }

        public void addTeam(String c, Location s, Location b) { 
            teamSpawns.put(c, s); 
            teamBeds.put(c, b); 
            brokenBeds.put(c, false); 
        }

        public void startCountdown(JavaPlugin pl) {
            state = ArenaState.STARTING;
            new BukkitRunnable() {
                @Override public void run() {
                    if (players.size() < 2) { 
                        state = ArenaState.WAITING; 
                        timer = 20; 
                        broadcast("§cНедостаточно игроков!");
                        this.cancel(); 
                        return; 
                    }
                    if (timer <= 0) { 
                        startGame(); 
                        this.cancel(); 
                        return; 
                    }
                    if (timer % 5 == 0 || timer <= 5) {
                        broadcast("§eСтарт через: §f" + timer);
                        for(Player p : players) playUniversalSound(p, "NOTE_PLING", "BLOCK_NOTE_PLING");
                    }
                    timer--;
                }
            }.runTaskTimer(pl, 0, 20);
        }

        public void startGame() {
            state = ArenaState.INGAME;
            List<String> colors = new ArrayList<>(teamSpawns.keySet());
            int i = 0;
            for (Player p : players) {
                String team = colors.get(i % colors.size());
                playerTeams.put(p, team);
                p.teleport(teamSpawns.get(team));
                p.getInventory().clear();
                p.getInventory().addItem(new ItemStack(Material.WOOD_SWORD));
                giveTeamArmor(p, team);
                p.setGameMode(GameMode.SURVIVAL);
                p.setLevel(0); 
                i++;
                addStat(p, "games_played", 1);
            }
            spawnNPCs();
            broadcast("§a§lИГРА НАЧАЛАСЬ!");
        }

        private void spawnNPCs() {
            clearNPCs();
            for (Location loc : teamShops.values()) {
                Villager v = (Villager) loc.getWorld().spawnEntity(loc, EntityType.VILLAGER);
                v.setAI(false); v.setCustomName("§b§lТОРГОВЕЦ"); v.setCustomNameVisible(true);
                npcs.add(v);
            }
            for (Location loc : teamUpgrades.values()) {
                Villager v = (Villager) loc.getWorld().spawnEntity(loc, EntityType.VILLAGER);
                v.setAI(false); v.setCustomName("§d§lУЛУЧШЕНИЯ"); v.setCustomNameVisible(true);
                npcs.add(v);
            }
        }

        public void clearNPCs() {
            for (Villager v : npcs) if (v != null) v.remove();
            npcs.clear();
        }

        public void runGameTick() {
            for (String team : teamSpawns.keySet()) {
                Location loc = teamSpawns.get(team);
                for (Player p : players) {
                    if (p.getLocation().getWorld().equals(loc.getWorld()) && p.getLocation().distance(loc) < 3.5) {
                        if (playerTeams.get(p).equals(team)) {
                            if (Math.random() < 0.25) {
                                p.setLevel(p.getLevel() + 1);
                                playUniversalSound(p, "ORB_PICKUP", "ENTITY_EXPERIENCE_ORB_PICKUP");
                            }
                            if (Math.random() < 0.08) {
                                p.setLevel(p.getLevel() + 1);
                            }
                        }
                    }
                }
            }
            for (Location loc : diamondGenerators) {
                if (Math.random() < 0.02) loc.getWorld().dropItemNaturally(loc, new ItemStack(Material.DIAMOND));
            }
            for (Location loc : emeraldGenerators) {
                if (Math.random() < 0.01) loc.getWorld().dropItemNaturally(loc, new ItemStack(Material.EMERALD));
            }
        }

        public void breakBed(String teamName, Player breaker) {
            brokenBeds.put(teamName, true);
            String bTeam = getPlayerTeam(breaker);
            ChatColor bColor = getTeamChatColor(bTeam);
            ChatColor tColor = getTeamChatColor(teamName);
            
            broadcast(" ");
            broadcast("§f§lУНИЧТОЖЕНИЕ КРОВАТИ!");
            broadcast("§fКровать команды " + tColor + teamName.toUpperCase() + " §fбыла уничтожена игроком " + bColor + breaker.getName() + "!");
            broadcast(" ");

            for (Player p : players) {
                playUniversalSound(p, "WITHER_SPAWN", "ENTITY_WITHER_SPAWN");
                p.sendTitle(tColor + "КРОВАТЬ СЛОМАНА!", "§7Команда " + teamName + " больше не респавнится", 10, 40, 10);
            }
        }

        public void checkWinCondition() {
            Set<String> aliveTeams = new HashSet<>();
            for (Player p : players) {
                if (p.getGameMode() == GameMode.SURVIVAL) {
                    aliveTeams.add(playerTeams.get(p));
                }
            }
            if (aliveTeams.size() <= 1 && state == ArenaState.INGAME) {
                String winner = aliveTeams.isEmpty() ? "НИКТО" : aliveTeams.iterator().next();
                ChatColor wColor = getTeamChatColor(winner);
                broadcast("§6§lИГРА ОКОНЧЕНА!");
                broadcast("§fПобедитель: " + wColor + winner.toUpperCase());
                
                for (Player p : players) {
                    if (playerTeams.get(p).equals(winner)) {
                        addStat(p, "wins", 1);
                    }
                }

                new BukkitRunnable() { @Override public void run() { stopGame(); } }.runTaskLater(VoidWars.getPlugin(VoidWars.class), 100);
            }
        }

        public void stopGame() {
            clearNPCs();
            for (Player p : players) {
                p.teleport(lobby != null ? lobby : Bukkit.getWorlds().get(0).getSpawnLocation());
                p.getInventory().clear();
                p.setGameMode(GameMode.SURVIVAL);
                p.setLevel(0);
                p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
                playerArenaMap.remove(p);
            }
            
            for (Location loc : placedBlocks) {
                Block b = loc.getBlock();
                if (b.getType() == Material.CHEST || b.getType() == Material.TRAPPED_CHEST) {
                    ((org.bukkit.block.Chest) b.getState()).getInventory().clear();
                }
                b.setType(Material.AIR);
            }
            placedBlocks.clear();
            players.clear();
            playerTeams.clear();
            brokenBeds.clear();
            state = ArenaState.WAITING;
        }

        public void updateScoreboard() {
            if (scoreboardConfig == null) return;
            
            String title = ChatColor.translateAlternateColorCodes('&', scoreboardConfig.getString("scoreboard.title", "&b&lVOID WARS"));
            List<String> rawLines = scoreboardConfig.getStringList("scoreboard.lines");

            for (Player p : players) {
                Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
                Objective obj = sb.registerNewObjective("vw", "dummy");
                obj.setDisplayName(title);
                obj.setDisplaySlot(DisplaySlot.SIDEBAR);
                
                int alivePlayers = 0;
                for (Player pl : players) if (pl.getGameMode() == GameMode.SURVIVAL) alivePlayers++;
                
                String myTeam = playerTeams.get(p);
                String bedStatus = brokenBeds.getOrDefault(myTeam, false) ? "§c✘" : "§a✔";

                int scoreIndex = rawLines.size();
                for (String line : rawLines) {
                    String formatted = line
                        .replace("%bed_status%", bedStatus)
                        .replace("%alive_count%", String.valueOf(alivePlayers))
                        .replace("%arena_name%", name);
                    
                    obj.getScore(ChatColor.translateAlternateColorCodes('&', formatted)).setScore(scoreIndex--);
                }
                
                p.setScoreboard(sb);
            }
        }

        public void addPlayer(Player p) { if(!players.contains(p)) players.add(p); }
        public void removePlayer(Player p) { 
            players.remove(p); 
            playerTeams.remove(p);
            p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
        }
        public void broadcast(String m) { for (Player p : players) p.sendMessage(m); }
        public void broadcastTeam(String team, String m) {
            for (Player p : players) if (team.equals(playerTeams.get(p))) p.sendMessage(m);
        }
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!(s instanceof Player)) return false;
        Player p = (Player) s;
        if (a.length < 1) return true;

        if (a[0].equalsIgnoreCase("create")) {
            if (a.length < 2) return true;
            Arena arena = new Arena(a[1]);
            arenas.put(a[1], arena);
            p.sendMessage(prefix + "§aАрена " + a[1] + " успешно создана.");
        } else if (a[0].equalsIgnoreCase("join")) {
            if (a.length < 2) return true;
            Arena arena = arenas.get(a[1]);
            if (arena != null) {
                arena.addPlayer(p);
                playerArenaMap.put(p, arena.getName());
                p.sendMessage(prefix + "§aВы вошли в игру!");
                if (arena.getPlayers().size() >= 2 && arena.getState() == ArenaState.WAITING) arena.startCountdown(this);
            }
        } else if (a[0].equalsIgnoreCase("leave")) {
            if (!playerArenaMap.containsKey(p)) {
                p.sendMessage(prefix + "§cВы не находитесь на арене!");
                return true;
            }
            Arena arena = arenas.get(playerArenaMap.get(p));
            if (arena != null) {
                arena.removePlayer(p);
                playerArenaMap.remove(p);
                p.teleport(arena.getLobby() != null ? arena.getLobby() : Bukkit.getWorlds().get(0).getSpawnLocation());
                p.getInventory().clear();
                p.sendMessage(prefix + "§eВы покинули арену.");
                arena.broadcast("§7Игрок §f" + p.getName() + " §7покинул игру.");
                if (arena.getState() == ArenaState.INGAME) arena.checkWinCondition();
            }
        } else if (a[0].equalsIgnoreCase("list")) {
            p.sendMessage(prefix + "§eСписок доступных арен:");
            if (arenas.isEmpty()) {
                p.sendMessage(" §7- Арен пока нет.");
            } else {
                for (Arena arena : arenas.values()) {
                    String status = "§aОжидание";
                    if (arena.getState() == ArenaState.STARTING) status = "§6Запуск";
                    if (arena.getState() == ArenaState.INGAME) status = "§cИдет игра";
                    p.sendMessage(" §8• §f" + arena.getName() + " §7(" + arena.getPlayers().size() + " игр.) - " + status);
                }
            }
        } else if (a[0].equalsIgnoreCase("stats")) {
            p.sendMessage("§b§lСТАТИСТИКА ИГРОКА §f" + p.getName());
            p.sendMessage("§7----------------------------");
            p.sendMessage(" §fПобед: §a" + getStat(p, "wins"));
            p.sendMessage(" §fУбийств: §e" + getStat(p, "kills"));
            p.sendMessage(" §fСломано кроватей: §c" + getStat(p, "beds_broken"));
            p.sendMessage(" §fСыграно игр: §b" + getStat(p, "games_played"));
            p.sendMessage("§7----------------------------");
        } else if (a[0].equalsIgnoreCase("setlobby")) {
            if (a.length < 2) return true;
            Arena arena = arenas.get(a[1]);
            if (arena != null) { 
                arena.setLobby(p.getLocation()); 
                saveArenaToFile(arena); 
                p.sendMessage(prefix + "§aТочка лобби для арены установлена."); 
            }
        } 
        else if (a[0].equalsIgnoreCase("reload")) {
            if (!p.hasPermission("voidwars.admin")) {
                p.sendMessage(prefix + "§cУ вас нет прав!");
                return true;
            }
            reloadPluginData();
            p.sendMessage(prefix + "§aКонфигурация плагина и Scoreboard успешно перезагружены!");
        }
        return true;
    }
}
